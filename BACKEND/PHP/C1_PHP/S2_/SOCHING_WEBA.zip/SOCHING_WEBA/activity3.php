before php tag
<?php
    $number = 5;
    echo "number initialize in first php tag";
?>

between php tags

<?php 
    echo "value of number in second php tag: " , $number ; // try to display the value of the variable $number here !
    
?>


after php tag