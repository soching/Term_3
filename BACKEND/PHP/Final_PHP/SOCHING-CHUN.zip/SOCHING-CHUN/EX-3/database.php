<?php
// TODO: connect to database
$db= new PDO ("mysql:host=localhost;dbname=blog_db", "root", "");
